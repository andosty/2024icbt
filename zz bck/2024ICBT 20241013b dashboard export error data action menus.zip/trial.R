setwd("C:/2024ICBT/")

source("Server/datapackages.R")
source("Server/hqdata/01_hq_data_download.R")
source("Server/hqdata/02_merge_for_final_file.R")
