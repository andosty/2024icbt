tabItem(
  tabName = "actionMenu",
  jumbotron(
    title = "Data Response Menu",  #heading
    status = "info",
    lead = "Return Error Cases back to responsible enumerators",  #sub heading
    btnName = "Reject Cases with Errors",
    href = "#",
    "Click to return cases with errors"
  ),
  
  fluidPage(
    div(
      h3("Data Download - Further Report Generation and Analysis"),
      selectInput("dataset", "select the dataset", choices=c("icbt data","icbt errors")),
      br(),
      helpText("select the download format"),
      # radioButtons("type","format type:",
      #              choices = c("Excel (CSV)","Stata","R")
      #              ),
      # br(),
      helpText("Click on the download button to download the dataset observations assigned to you"),
      downloadButton('downloadData','Download'),
      
      # tableOutput(outputId = 'selectedDataset'),
      
    )
  )
  
  

)
